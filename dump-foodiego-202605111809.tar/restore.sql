--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE foodiego;
--
-- Name: foodiego; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE foodiego WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE foodiego OWNER TO postgres;

\unrestrict (null)
\connect foodiego
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id bigint NOT NULL,
    user_id bigint,
    apartment character varying(255),
    city character varying(255),
    district character varying(255) NOT NULL,
    receiver_name character varying(255),
    receiver_phone character varying(255),
    room_number character varying(255)
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.address_id_seq OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.address_id_seq OWNED BY public.address.id;


--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    id bigint NOT NULL,
    category_icon character varying(500000),
    category_description character varying(255),
    category_name character varying(255)
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.category_id_seq OWNER TO postgres;

--
-- Name: category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_id_seq OWNED BY public.category.id;


--
-- Name: foods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.foods (
    price double precision NOT NULL,
    category_id bigint NOT NULL,
    id bigint NOT NULL,
    restaurant_id bigint,
    description character varying(5000),
    image character varying(500000),
    name character varying(255) NOT NULL
);


ALTER TABLE public.foods OWNER TO postgres;

--
-- Name: foods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.foods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.foods_id_seq OWNER TO postgres;

--
-- Name: foods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.foods_id_seq OWNED BY public.foods.id;


--
-- Name: order_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_details (
    price double precision NOT NULL,
    quantity integer NOT NULL,
    food_id bigint,
    id bigint NOT NULL,
    order_id bigint
);


ALTER TABLE public.order_details OWNER TO postgres;

--
-- Name: order_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_details_id_seq OWNER TO postgres;

--
-- Name: order_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_details_id_seq OWNED BY public.order_details.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    price double precision NOT NULL,
    quantity integer NOT NULL,
    food_id bigint NOT NULL,
    id bigint NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    total_price double precision NOT NULL,
    id bigint NOT NULL,
    user_id bigint,
    status character varying(255),
    completed boolean DEFAULT false
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: ratings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ratings (
    id bigint NOT NULL,
    rating_value integer,
    user_id bigint,
    restaurant_id bigint
);


ALTER TABLE public.ratings OWNER TO postgres;

--
-- Name: ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ratings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ratings_id_seq OWNER TO postgres;

--
-- Name: ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ratings_id_seq OWNED BY public.ratings.id;


--
-- Name: restaurant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant (
    delivery_fee double precision,
    delivery_time integer,
    rating double precision,
    category_id bigint,
    id bigint NOT NULL,
    manager_user_id bigint,
    description character varying(5000),
    banner_url character varying(500000),
    logo_url character varying(500000),
    address character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    phone_number character varying(255),
    working_hours character varying(255),
    total_ratings integer
);


ALTER TABLE public.restaurant OWNER TO postgres;

--
-- Name: restaurant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.restaurant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.restaurant_id_seq OWNER TO postgres;

--
-- Name: restaurant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.restaurant_id_seq OWNED BY public.restaurant.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    rating integer NOT NULL,
    foods_id bigint,
    id bigint NOT NULL,
    user_id bigint,
    comment character varying(255),
    restaurant_id bigint
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reviews_id_seq OWNER TO postgres;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    created_at timestamp(6) without time zone,
    id bigint NOT NULL,
    updated_at timestamp(6) without time zone,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    phone character varying(255),
    role character varying(255) NOT NULL,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['CUSTOMER'::character varying, 'ADMIN'::character varying, 'RESTAURANT'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address ALTER COLUMN id SET DEFAULT nextval('public.address_id_seq'::regclass);


--
-- Name: category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category ALTER COLUMN id SET DEFAULT nextval('public.category_id_seq'::regclass);


--
-- Name: foods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.foods ALTER COLUMN id SET DEFAULT nextval('public.foods_id_seq'::regclass);


--
-- Name: order_details id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details ALTER COLUMN id SET DEFAULT nextval('public.order_details_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: ratings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings ALTER COLUMN id SET DEFAULT nextval('public.ratings_id_seq'::regclass);


--
-- Name: restaurant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant ALTER COLUMN id SET DEFAULT nextval('public.restaurant_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (id, user_id, apartment, city, district, receiver_name, receiver_phone, room_number) FROM stdin;
\.
COPY public.address (id, user_id, apartment, city, district, receiver_name, receiver_phone, room_number) FROM '$$PATH$$/4978.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (id, category_icon, category_description, category_name) FROM stdin;
\.
COPY public.category (id, category_icon, category_description, category_name) FROM '$$PATH$$/4980.dat';

--
-- Data for Name: foods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.foods (price, category_id, id, restaurant_id, description, image, name) FROM stdin;
\.
COPY public.foods (price, category_id, id, restaurant_id, description, image, name) FROM '$$PATH$$/4982.dat';

--
-- Data for Name: order_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_details (price, quantity, food_id, id, order_id) FROM stdin;
\.
COPY public.order_details (price, quantity, food_id, id, order_id) FROM '$$PATH$$/4984.dat';

--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (price, quantity, food_id, id) FROM stdin;
\.
COPY public.order_items (price, quantity, food_id, id) FROM '$$PATH$$/4986.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (total_price, id, user_id, status, completed) FROM stdin;
\.
COPY public.orders (total_price, id, user_id, status, completed) FROM '$$PATH$$/4988.dat';

--
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ratings (id, rating_value, user_id, restaurant_id) FROM stdin;
\.
COPY public.ratings (id, rating_value, user_id, restaurant_id) FROM '$$PATH$$/4996.dat';

--
-- Data for Name: restaurant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurant (delivery_fee, delivery_time, rating, category_id, id, manager_user_id, description, banner_url, logo_url, address, name, phone_number, working_hours, total_ratings) FROM stdin;
\.
COPY public.restaurant (delivery_fee, delivery_time, rating, category_id, id, manager_user_id, description, banner_url, logo_url, address, name, phone_number, working_hours, total_ratings) FROM '$$PATH$$/4990.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (rating, foods_id, id, user_id, comment, restaurant_id) FROM stdin;
\.
COPY public.reviews (rating, foods_id, id, user_id, comment, restaurant_id) FROM '$$PATH$$/4992.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (created_at, id, updated_at, email, name, password, phone, role) FROM stdin;
\.
COPY public.users (created_at, id, updated_at, email, name, password, phone, role) FROM '$$PATH$$/4994.dat';

--
-- Name: address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.address_id_seq', 10, true);


--
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_id_seq', 30, true);


--
-- Name: foods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.foods_id_seq', 900, true);


--
-- Name: order_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_details_id_seq', 10, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 10, true);


--
-- Name: ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ratings_id_seq', 1, false);


--
-- Name: restaurant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.restaurant_id_seq', 15, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: 24872..26196; Type: BLOB METADATA; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24872');
SELECT pg_catalog.lo_create('24873');
SELECT pg_catalog.lo_create('24874');
SELECT pg_catalog.lo_create('24875');
SELECT pg_catalog.lo_create('24876');
SELECT pg_catalog.lo_create('24877');
SELECT pg_catalog.lo_create('24878');
SELECT pg_catalog.lo_create('24879');
SELECT pg_catalog.lo_create('24880');
SELECT pg_catalog.lo_create('24881');
SELECT pg_catalog.lo_create('24882');
SELECT pg_catalog.lo_create('24883');
SELECT pg_catalog.lo_create('24885');
SELECT pg_catalog.lo_create('24886');
SELECT pg_catalog.lo_create('24887');
SELECT pg_catalog.lo_create('24888');
SELECT pg_catalog.lo_create('24889');
SELECT pg_catalog.lo_create('24904');
SELECT pg_catalog.lo_create('25105');
SELECT pg_catalog.lo_create('25205');
SELECT pg_catalog.lo_create('25817');
SELECT pg_catalog.lo_create('25925');
SELECT pg_catalog.lo_create('25926');
SELECT pg_catalog.lo_create('26032');
SELECT pg_catalog.lo_create('26033');
SELECT pg_catalog.lo_create('26034');
SELECT pg_catalog.lo_create('26035');
SELECT pg_catalog.lo_create('26036');
SELECT pg_catalog.lo_create('26037');
SELECT pg_catalog.lo_create('26038');
SELECT pg_catalog.lo_create('26148');
SELECT pg_catalog.lo_create('26149');
SELECT pg_catalog.lo_create('26196');

ALTER LARGE OBJECT 24872 OWNER TO postgres;
ALTER LARGE OBJECT 24873 OWNER TO postgres;
ALTER LARGE OBJECT 24874 OWNER TO postgres;
ALTER LARGE OBJECT 24875 OWNER TO postgres;
ALTER LARGE OBJECT 24876 OWNER TO postgres;
ALTER LARGE OBJECT 24877 OWNER TO postgres;
ALTER LARGE OBJECT 24878 OWNER TO postgres;
ALTER LARGE OBJECT 24879 OWNER TO postgres;
ALTER LARGE OBJECT 24880 OWNER TO postgres;
ALTER LARGE OBJECT 24881 OWNER TO postgres;
ALTER LARGE OBJECT 24882 OWNER TO postgres;
ALTER LARGE OBJECT 24883 OWNER TO postgres;
ALTER LARGE OBJECT 24885 OWNER TO postgres;
ALTER LARGE OBJECT 24886 OWNER TO postgres;
ALTER LARGE OBJECT 24887 OWNER TO postgres;
ALTER LARGE OBJECT 24888 OWNER TO postgres;
ALTER LARGE OBJECT 24889 OWNER TO postgres;
ALTER LARGE OBJECT 24904 OWNER TO postgres;
ALTER LARGE OBJECT 25105 OWNER TO postgres;
ALTER LARGE OBJECT 25205 OWNER TO postgres;
ALTER LARGE OBJECT 25817 OWNER TO postgres;
ALTER LARGE OBJECT 25925 OWNER TO postgres;
ALTER LARGE OBJECT 25926 OWNER TO postgres;
ALTER LARGE OBJECT 26032 OWNER TO postgres;
ALTER LARGE OBJECT 26033 OWNER TO postgres;
ALTER LARGE OBJECT 26034 OWNER TO postgres;
ALTER LARGE OBJECT 26035 OWNER TO postgres;
ALTER LARGE OBJECT 26036 OWNER TO postgres;
ALTER LARGE OBJECT 26037 OWNER TO postgres;
ALTER LARGE OBJECT 26038 OWNER TO postgres;
ALTER LARGE OBJECT 26148 OWNER TO postgres;
ALTER LARGE OBJECT 26149 OWNER TO postgres;
ALTER LARGE OBJECT 26196 OWNER TO postgres;

--
-- Data for Name: 24872..26196; Type: BLOBS; Schema: -; Owner: postgres
--

\i $$PATH$$/4998.dat

--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: foods foods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_pkey PRIMARY KEY (id);


--
-- Name: order_details order_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details
    ADD CONSTRAINT order_details_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: ratings ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_pkey PRIMARY KEY (id);


--
-- Name: restaurant restaurant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT restaurant_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: order_items fk1huo7mby94sw84wam6xbfaex2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk1huo7mby94sw84wam6xbfaex2 FOREIGN KEY (food_id) REFERENCES public.foods(id);


--
-- Name: orders fk32ql8ubntj5uh44ph9659tiih; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk32ql8ubntj5uh44ph9659tiih FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: address fk6i66ijb8twgcqtetl8eeeed6v; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT fk6i66ijb8twgcqtetl8eeeed6v FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: restaurant fk8jj0ghjhpw9xiue5pkqxb67s7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT fk8jj0ghjhpw9xiue5pkqxb67s7 FOREIGN KEY (category_id) REFERENCES public.category(id);


--
-- Name: reviews fkcgy7qjc1r99dp117y9en6lxye; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fkcgy7qjc1r99dp117y9en6lxye FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ratings fkh7l3gje9yw8ufmte2ocedljno; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT fkh7l3gje9yw8ufmte2ocedljno FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id);


--
-- Name: order_details fkjyu2qbqt8gnvno9oe9j2s2ldk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details
    ADD CONSTRAINT fkjyu2qbqt8gnvno9oe9j2s2ldk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: foods fklto096lnvn3dfml7toi92r1t9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT fklto096lnvn3dfml7toi92r1t9 FOREIGN KEY (category_id) REFERENCES public.category(id);


--
-- Name: reviews fkm91qx6nnuctuj8rqbqyqu7vsj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fkm91qx6nnuctuj8rqbqyqu7vsj FOREIGN KEY (foods_id) REFERENCES public.foods(id);


--
-- Name: foods fkneb95aieqlywxmupkm3mqn8y6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT fkneb95aieqlywxmupkm3mqn8y6 FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id);


--
-- Name: reviews fkx4vr3w78d7sql5oeb7puqcj8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fkx4vr3w78d7sql5oeb7puqcj8 FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id);


--
-- PostgreSQL database dump complete
--

